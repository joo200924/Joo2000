export const Card = ({ children }) => <div className='border rounded-xl shadow'>{children}</div>;
export const CardContent = ({ children, className }) => <div className={className}>{children}</div>;