import { useState } from "react";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

export default function توقع_جو() {
  const [input, setInput] = useState("");
  const [recommendation, setRecommendation] = useState(null);
  const [copied, setCopied] = useState(false);

  const handleAnalyze = () => {
    const numbers = input
      .split(/\s|,|\n/)
      .map((n) => parseFloat(n))
      .filter((n) => !isNaN(n));

    const lowRounds = numbers.filter((n) => n < 1.5).length;
    const last = numbers[numbers.length - 1];

    let suggestion = "لا تشارك الآن";
    let cashout = "-";

    if (lowRounds >= 3 && last < 1.5) {
      suggestion = "فرصة جيدة للدخول!";
      cashout = "×1.8 - ×2";
    } else if (last > 10) {
      suggestion = "انتظر جولات أقل";
    }

    setRecommendation({ suggestion, cashout });
    setCopied(false);
  };

  const handleCopy = () => {
    if (recommendation) {
      const text = `التوصية: ${recommendation.suggestion}\nاسحب على: ${recommendation.cashout}`;
      navigator.clipboard.writeText(text).then(() => setCopied(true));
    }
  };

  const handleReset = () => {
    setInput("");
    setRecommendation(null);
    setCopied(false);
  };

  const handleShare = () => {
    if (recommendation) {
      const text = `التوصية: ${recommendation.suggestion}%0Aاسحب على: ${recommendation.cashout}`;
      const url = `https://wa.me/?text=${text}`;
      window.open(url, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-white text-black p-4 max-w-xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-4">توقع جو</h1>
      <Card>
        <CardContent className="space-y-4 p-4">
          <p>أدخل نتائج آخر الجولات (مفصولة بفواصل أو مسافات):</p>
          <Input
            placeholder="مثال: 1.2, 2.8, 1.5, 3.1 ..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <div className="flex gap-2">
            <Button onClick={handleAnalyze}>تحليل</Button>
            <Button variant="secondary" onClick={handleReset}>إعادة تعيين</Button>
          </div>
          {recommendation && (
            <div className="bg-green-100 p-4 rounded-xl text-right space-y-2">
              <p className="font-bold">{recommendation.suggestion}</p>
              <p>اسحب على: {recommendation.cashout}</p>
              <div className="flex items-center gap-2 flex-wrap">
                <Button onClick={handleCopy} className="text-sm">نسخ التوصية</Button>
                <Button variant="outline" onClick={handleShare} className="text-sm">مشاركة واتساب</Button>
                {copied && <span className="text-green-600 text-sm">تم النسخ!</span>}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
