
import React from "react";
import توقع_جو from "./components/توقع_جو";

function App() {
  return <توقع_جو />;
}

export default App;
